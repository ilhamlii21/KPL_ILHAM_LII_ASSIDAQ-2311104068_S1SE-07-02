﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPMODUL12
{
        public class Helper
        {
            public static string CariTandaBilangan(int a)
            {
                if (a < 0) return "iniBilangan Negatif";
                else if (a > 0) return "iniBilangan Positif";
                else return "iniBilangan Nol";
            }
        }
}
