﻿using TPMODUL12;

namespace UnitTestTP12
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestNegatif()
        {
            string result = Helper.CariTandaBilangan(-10);
            Assert.AreEqual("iniBilangan Negatif", result);
        }

        [TestMethod]
        public void TestPositif()
        {
            string result = Helper.CariTandaBilangan(10);
            Assert.AreEqual("iniBilangan Positif", result);
        }

        [TestMethod]
        public void TestNol()
        {
            string result = Helper.CariTandaBilangan(0);
            Assert.AreEqual("iniBilangan Nol", result);
        }
    }
}
